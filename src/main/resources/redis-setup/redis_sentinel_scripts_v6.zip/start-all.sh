#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

"${BASE_DIR}/start-redis.sh"
"${BASE_DIR}/sentinel-start.sh"
