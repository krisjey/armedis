#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

REDIS_SERVER="${SCRIPT_DIR}/redis-server"
CONF_FILE="${SCRIPT_DIR}/sentinel.conf"

if [[ ! -x "$REDIS_SERVER" ]]; then
  echo "redis-server 실행 파일을 ${REDIS_SERVER} 에서 찾을 수 없습니다."
  echo "setup.sh 실행 후 다시 시도하세요."
  exit 1
fi

if [[ ! -f "$CONF_FILE" ]]; then
  echo "sentinel.conf 파일을 ${CONF_FILE} 에서 찾을 수 없습니다."
  exit 1
fi

PID_FILE="$(awk '/^pidfile/ {gsub(/"/,"",$2); print $2}' "$CONF_FILE" || true)"

if [[ -n "${PID_FILE:-}" && -f "$PID_FILE" ]]; then
  PID="$(cat "$PID_FILE")"
  if kill -0 "$PID" 2>/dev/null; then
    echo "이미 Sentinel 인스턴스가 실행 중입니다. (PID=$PID)"
    exit 0
  else
    echo "이전 Sentinel 실행의 PID 파일이 남아 있습니다. PID 파일을 삭제합니다."
    rm -f "$PID_FILE"
  fi
fi

echo "Redis Sentinel 인스턴스를 시작합니다..."
"$REDIS_SERVER" "$CONF_FILE" --sentinel

# PID 파일이 생성될 때까지 최대 10초 대기
for i in {1..10}; do
  if [[ -n "${PID_FILE:-}" && -f "$PID_FILE" ]]; then
    echo "Sentinel 시작 완료. PID=$(cat "$PID_FILE")"
    exit 0
  fi
  sleep 1
done

echo "경고: PID 파일(${PID_FILE})을 찾을 수 없습니다. sentinel.conf 설정 또는 Sentinel 로그를 확인하세요."
