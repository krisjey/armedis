#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Redis Sentinel 인스턴스를 시작합니다..."

"${BASE_DIR}/sentinel1/start.sh"
"${BASE_DIR}/sentinel2/start.sh"
"${BASE_DIR}/sentinel3/start.sh"

echo "Redis Sentinel 시작 완료."
