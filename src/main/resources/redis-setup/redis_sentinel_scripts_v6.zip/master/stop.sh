#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

CONF_FILE="${SCRIPT_DIR}/redis.conf"

if [[ ! -f "$CONF_FILE" ]]; then
  echo "redis.conf 파일을 ${CONF_FILE} 에서 찾을 수 없습니다."
  exit 1
fi

PID_FILE="$(awk '/^pidfile/ {gsub(/"/,"",$2); print $2}' "$CONF_FILE" || true)"

if [[ -z "${PID_FILE:-}" || ! -f "$PID_FILE" ]]; then
  echo "PID 파일을 찾을 수 없습니다. 이미 종료되었거나 설정이 잘못되었을 수 있습니다."
  exit 0
fi

PID="$(cat "$PID_FILE")"
if kill -0 "$PID" 2>/dev/null; then
  echo "Redis(PID=$PID)를 종료합니다..."
  kill "$PID"
  for i in {1..30}; do
    if kill -0 "$PID" 2>/dev/null; then
      sleep 1
    else
      break
    fi
  done
else
  echo "PID=$PID 프로세스가 존재하지 않습니다. PID 파일을 삭제합니다."
fi

rm -f "$PID_FILE"
echo "종료 완료."
