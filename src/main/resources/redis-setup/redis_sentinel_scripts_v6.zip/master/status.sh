#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

CONF_FILE="${SCRIPT_DIR}/redis.conf"

if [[ ! -f "$CONF_FILE" ]]; then
  echo "redis.conf 파일을 ${CONF_FILE} 에서 찾을 수 없습니다."
  exit 1
fi

PID_FILE="$(awk '/^pidfile/ {gsub(/"/,"",$2); print $2}' "$CONF_FILE" || true)"

if [[ -z "${PID_FILE:-}" || ! -f "$PID_FILE" ]]; then
  echo "상태: STOPPED (PID 파일 없음)"
  exit 0
fi

PID="$(cat "$PID_FILE")"
if kill -0 "$PID" 2>/dev/null; then
  echo "상태: RUNNING (PID=$PID, PID 파일:${PID_FILE})"
else
  echo "상태: STALE (PID 파일은 있으나 프로세스가 없습니다. PID 파일 삭제 필요)"
fi
