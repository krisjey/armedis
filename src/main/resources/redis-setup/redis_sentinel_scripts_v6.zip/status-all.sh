#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== Redis 상태 ==="
echo "[master]"
"${BASE_DIR}/master/status.sh" || true
echo "[slave1]"
"${BASE_DIR}/slave1/status.sh" || true
echo "[slave2]"
"${BASE_DIR}/slave2/status.sh" || true

echo
echo "=== Sentinel 상태 ==="
echo "[sentinel1]"
"${BASE_DIR}/sentinel1/status.sh" || true
echo "[sentinel2]"
"${BASE_DIR}/sentinel2/status.sh" || true
echo "[sentinel3]"
"${BASE_DIR}/sentinel3/status.sh" || true
