#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Redis Sentinel 인스턴스를 종료합니다..."

"${BASE_DIR}/sentinel3/stop.sh" || true
"${BASE_DIR}/sentinel2/stop.sh" || true
"${BASE_DIR}/sentinel1/stop.sh" || true

echo "Redis Sentinel 종료 완료."
