#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

"${BASE_DIR}/sentinel-stop.sh" || true
"${BASE_DIR}/stop-redis.sh" || true
