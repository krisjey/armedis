#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

MASTER_HOST="192.168.56.105"
MASTER_PORT="8500"
SLAVE_PORT="8501"
SENTINEL_PORT="26379"
MASTER_NAME="mymaster"

if ! command -v redis-cli >/dev/null 2>&1; then
  echo "redis-cli 명령을 찾을 수 없습니다. PATH 설정 또는 redis-cli 설치를 확인하세요."
  exit 1
fi

echo "=== 현재 복제 상태(slave1 기준) ==="
redis-cli -h "$MASTER_HOST" -p "$SLAVE_PORT" INFO replication | egrep "role:|master_host|master_port|slave[0-9]+:" || true

echo
echo "마스터를 종료하여 failover 를 트리거합니다..."
"${BASE_DIR}/master/stop.sh" || true

echo "Sentinel 이 failover 를 수행할 때까지 기다립니다...(최대 60초)"
for i in {1..60}; do
  NEW_MASTER="$(redis-cli -h "$MASTER_HOST" -p "$SENTINEL_PORT" SENTINEL get-master-addr-by-name "$MASTER_NAME" 2>/dev/null | tr '\n' ' ')"
  if [[ -n "${NEW_MASTER// }" ]]; then
    echo "Sentinel 이 보고하는 현재 master: ${NEW_MASTER}"
    break
  fi
  sleep 1
done

echo
echo "failover 이후 복제 상태(slave1 기준)"
redis-cli -h "$MASTER_HOST" -p "$SLAVE_PORT" INFO replication | egrep "role:|master_host|master_port|slave[0-9]+:" || true

echo
echo "주의: 실제 운영 환경에서는 failover 테스트를 매우 신중하게 수행해야 합니다."
