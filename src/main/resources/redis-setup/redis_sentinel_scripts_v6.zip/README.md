Redis Sentinel Cluster Scripts v6
=================================

- pidfile/logfile 경로에 따옴표가 포함되어 있어도 정상 동작하도록,
  모든 start/stop/status 스크립트에서 awk로 pidfile 값을 읽을 때 gsub(/"/,"",$2) 로 따옴표 제거.
- Redis / Sentinel 시작 시 PID 파일 생성을 최대 10초까지 기다린 후,
  없을 때만 경고를 출력하도록 수정하여 race condition 완화.
