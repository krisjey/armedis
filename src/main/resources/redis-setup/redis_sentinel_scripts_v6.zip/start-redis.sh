#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Redis master/slave 인스턴스를 시작합니다..."

"${BASE_DIR}/master/start.sh"
"${BASE_DIR}/slave1/start.sh"
"${BASE_DIR}/slave2/start.sh"

echo "Redis master/slave 시작 완료."
