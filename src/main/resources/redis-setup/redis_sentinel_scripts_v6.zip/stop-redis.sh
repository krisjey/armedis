#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Redis master/slave 인스턴스를 종료합니다..."

"${BASE_DIR}/slave2/stop.sh" || true
"${BASE_DIR}/slave1/stop.sh" || true
"${BASE_DIR}/master/stop.sh" || true

echo "Redis master/slave 종료 완료."
