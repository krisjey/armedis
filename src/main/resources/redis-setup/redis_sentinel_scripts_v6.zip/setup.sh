#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

SRC_REDIS_SERVER="/work/install/redis-7.4.4/src/redis-server"
SRC_REDIS_CONF="/work/install/redis-7.4.4/redis.conf"

if [[ ! -x "$SRC_REDIS_SERVER" ]]; then
  echo "원본 redis-server(${SRC_REDIS_SERVER}) 를 찾을 수 없습니다."
  echo "경로를 확인한 후 다시 실행하세요."
  exit 1
fi

if [[ ! -f "$SRC_REDIS_CONF" ]]; then
  echo "원본 redis.conf(${SRC_REDIS_CONF}) 를 찾을 수 없습니다."
  echo "경로를 확인한 후 다시 실행하세요."
  exit 1
fi

echo "redis-server 바이너리 복사..."
for d in master slave1 slave2 sentinel1 sentinel2 sentinel3; do
  mkdir -p "${BASE_DIR}/${d}"
  cp "$SRC_REDIS_SERVER" "${BASE_DIR}/${d}/redis-server"
  chmod +x "${BASE_DIR}/${d}/redis-server"
done

echo "기본 redis.conf 템플릿 복사(참고용)"
cp "$SRC_REDIS_CONF" "${BASE_DIR}/redis.conf.template"

echo "구성이 완료되었습니다."
echo "start-all.sh 를 사용하여 전체 Redis + Sentinel 을 시작할 수 있습니다."
