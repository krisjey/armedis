#!/usr/bin/env bash
set -euo pipefail

# 현재 스크립트 기준 디렉토리
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

SRC_BASE="/work/install/redis-7.4.4"
SRC_SERVER="${SRC_BASE}/src/redis-server"
SRC_CONF="${SRC_BASE}/redis.conf"

echo "[setup] BASE_DIR=${BASE_DIR}"
echo "[setup] SRC_SERVER=${SRC_SERVER}"
echo "[setup] SRC_CONF=${SRC_CONF}"

if [[ ! -x "${SRC_SERVER}" ]]; then
  echo "[ERROR] redis-server 실행 파일을 찾을 수 없거나 실행 권한이 없습니다: ${SRC_SERVER}" >&2
  exit 1
fi

if [[ ! -f "${SRC_CONF}" ]]; then
  echo "[ERROR] redis.conf 파일을 찾을 수 없습니다: ${SRC_CONF}" >&2
  exit 1
fi

# 바이너리 / 설정 복사
cp "${SRC_SERVER}" "${BASE_DIR}/redis-server"
cp "${SRC_CONF}"  "${BASE_DIR}/redis.conf"

chmod +x "${BASE_DIR}/redis-server"

CONF_FILE="${BASE_DIR}/redis.conf"

echo "[setup] redis.conf 설정값 수정..."

# port 설정
if grep -q -E '^[[:space:]]*port[[:space:]]+' "${CONF_FILE}"; then
  sed -i 's/^[[:space:]]*port[[:space:]]\+.*$/port 6379/' "${CONF_FILE}"
else
  echo "port 6379" >> "${CONF_FILE}"
fi

# bind 설정
if grep -q -E '^[[:space:]]*bind[[:space:]]+' "${CONF_FILE}"; then
  sed -i 's/^[[:space:]]*bind[[:space:]]\+.*/bind 192.168.56.105/' "${CONF_FILE}"
else
  echo "bind 192.168.56.105" >> "${CONF_FILE}"
fi

# daemonize 설정
if grep -q -E '^[[:space:]]*daemonize[[:space:]]+' "${CONF_FILE}"; then
  sed -i 's/^[[:space:]]*daemonize[[:space:]]\+.*/daemonize yes/' "${CONF_FILE}"
else
  echo "daemonize yes" >> "${CONF_FILE}"
fi

# pidfile 설정 (redis.conf가 있는 폴더에 생성)
if grep -q -E '^[[:space:]]*pidfile[[:space:]]+' "${CONF_FILE}"; then
  sed -i 's|^[[:space:]]*pidfile[[:space:]]\+.*$|pidfile redis.pid|' "${CONF_FILE}"
else
  echo "pidfile redis.pid" >> "${CONF_FILE}"
fi

echo "[setup] 완료. 디렉토리: ${BASE_DIR}"
echo "  - redis-server"
echo "  - redis.conf (port=6379, bind=192.168.56.105, daemonize=yes, pidfile=redis.pid 로 설정됨)"
echo
echo "이제 ${BASE_DIR} 에서 ./start.sh 로 Redis를 시작할 수 있습니다."
