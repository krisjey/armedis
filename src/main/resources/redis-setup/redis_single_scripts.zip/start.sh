#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${BASE_DIR}"

PID_FILE="${BASE_DIR}/redis.pid"
CONF_FILE="${BASE_DIR}/redis.conf"
SERVER="${BASE_DIR}/redis-server"

if [[ ! -x "${SERVER}" ]]; then
  echo "[ERROR] redis-server 실행 파일이 없습니다. 먼저 ./setup.sh 를 실행해 주세요." >&2
  exit 1
fi

if [[ ! -f "${CONF_FILE}" ]]; then
  echo "[ERROR] redis.conf 파일이 없습니다. 먼저 ./setup.sh 를 실행해 주세요." >&2
  exit 1
fi

if [[ -f "${PID_FILE}" ]]; then
  OLD_PID="$(cat "${PID_FILE}" || true)"
  if [[ -n "${OLD_PID}" ]] && ps -p "${OLD_PID}" > /dev/null 2>&1; then
    echo "[WARN] Redis가 이미 실행 중인 것 같습니다. (PID=${OLD_PID})"
    exit 0
  else
    echo "[WARN] 기존 PID 파일이 있지만 프로세스는 없습니다. PID 파일을 삭제합니다."
    rm -f "${PID_FILE}"
  fi
fi

echo "[start] redis-server 를 시작합니다..."
"${SERVER}" "${CONF_FILE}"

sleep 1

if [[ -f "${PID_FILE}" ]]; then
  NEW_PID="$(cat "${PID_FILE}")"
  echo "[start] Redis가 시작되었습니다. PID=${NEW_PID}"
else
  echo "[WARN] PID 파일이 생성되지 않았습니다. redis.conf 의 설정을 확인해 주세요." >&2
fi
