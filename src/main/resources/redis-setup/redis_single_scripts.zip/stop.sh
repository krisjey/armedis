#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_FILE="${BASE_DIR}/redis.pid"

if [[ ! -f "${PID_FILE}" ]]; then
  echo "[stop] PID 파일이 없습니다: ${PID_FILE}"
  echo "이미 종료되었거나 아직 시작되지 않은 상태일 수 있습니다."
  exit 0
fi

PID="$(cat "${PID_FILE}" || true)"

if [[ -z "${PID}" ]]; then
  echo "[stop] PID 파일이 비어 있습니다. 파일을 삭제합니다."
  rm -f "${PID_FILE}"
  exit 0
fi

if ! ps -p "${PID}" > /dev/null 2>&1; then
  echo "[stop] PID=${PID} 프로세스가 존재하지 않습니다. PID 파일만 삭제합니다."
  rm -f "${PID_FILE}"
  exit 0
fi

echo "[stop] Redis 프로세스 종료 시도 (PID=${PID})..."
kill "${PID}"

# 최대 10초 대기
for i in $(seq 1 10); do
  if ! ps -p "${PID}" > /dev/null 2>&1; then
    echo "[stop] 정상적으로 종료되었습니다."
    rm -f "${PID_FILE}"
    exit 0
  fi
  sleep 1
fi

echo "[stop] 일반 종료 실패. 강제 종료를 시도합니다."
kill -9 "${PID}" || true
rm -f "${PID_FILE}"
echo "[stop] 강제 종료 및 PID 파일 제거 완료."
