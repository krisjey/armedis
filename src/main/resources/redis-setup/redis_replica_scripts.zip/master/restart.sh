#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

"${SCRIPT_DIR}/stop.sh" || true
sleep 1
"${SCRIPT_DIR}/start.sh"
