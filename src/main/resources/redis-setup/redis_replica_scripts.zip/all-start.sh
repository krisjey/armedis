#!/usr/bin/env bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

"${BASE_DIR}/master/start.sh"
"${BASE_DIR}/slave1/start.sh"
"${BASE_DIR}/slave2/start.sh"
