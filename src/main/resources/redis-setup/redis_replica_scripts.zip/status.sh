#!/usr/bin/env bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== PROCESS STATUS (PIDFILE) ==="
"${BASE_DIR}/master/status.sh"  || true
"${BASE_DIR}/slave1/status.sh"  || true
"${BASE_DIR}/slave2/status.sh"  || true

echo
echo "=== ROLE STATUS (INFO replication) ==="

check_role() {
  local NAME="$1"
  local PORT="$2"
  local DIR="$3"

  local CLI="${DIR}/redis-cli"
  if [[ ! -x "${CLI}" ]]; then
    echo "[${NAME}] redis-cli not found."
    return
  fi

  ROLE="$("${CLI}" -h 127.0.0.1 -p "${PORT}" INFO replication 2>/dev/null | grep '^role:' | cut -d':' -f2 | tr -d '\r')"

  if [[ -n "${ROLE}" ]]; then
    echo "[${NAME}] port=${PORT}, role=${ROLE}"
  else
    echo "[${NAME}] port=${PORT}, not responding."
  fi
}

check_role "MASTER" 8000 "${BASE_DIR}/master"
check_role "SLAVE1" 8101 "${BASE_DIR}/slave1"
check_role "SLAVE2" 8102 "${BASE_DIR}/slave2"
