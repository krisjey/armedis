#!/usr/bin/env bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

MASTER_STOP="${BASE_DIR}/master/stop.sh"
SLAVE1_DIR="${BASE_DIR}/slave1"
SLAVE1_CLI="${SLAVE1_DIR}/redis-cli"

echo "[FAILOVER] Stopping master (8000)..."
"${MASTER_STOP}" || true
sleep 2

if [[ ! -x "${SLAVE1_CLI}" ]]; then
  echo "[FAILOVER] redis-cli for slave1 not found."
  exit 1
fi

echo "[FAILOVER] Promoting slave1 (8101) to master (REPLICAOF NO ONE)..."
"${SLAVE1_CLI}" -h 127.0.0.1 -p 8101 REPLICAOF NO ONE

sleep 2
echo "[FAILOVER] Status after failover:"
"${BASE_DIR}/status.sh"
