#!/usr/bin/env bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

PORTS=("8000" "8101" "8102")

for PORT in "${PORTS[@]}"; do
  case "${PORT}" in
    8000) DIR="${BASE_DIR}/master" ;;
    8101) DIR="${BASE_DIR}/slave1" ;;
    8102) DIR="${BASE_DIR}/slave2" ;;
    *) continue ;;
  esac

  CLI="${DIR}/redis-cli"
  if [[ ! -x "${CLI}" ]]; then
    echo "[WARN] redis-cli not found for port ${PORT}, skip."
    continue
  fi

  ROLE="$("${CLI}" -h 127.0.0.1 -p "${PORT}" INFO replication 2>/dev/null | grep '^role:' | cut -d':' -f2 | tr -d '\r')"

  if [[ "${ROLE}" == "master" ]]; then
    echo "[MASTER-STOP] Found master at port ${PORT}. Shutting down..."
    "${CLI}" -h 127.0.0.1 -p "${PORT}" SHUTDOWN
  fi
done
