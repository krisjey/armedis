#!/usr/bin/env bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

"${BASE_DIR}/master/stop.sh" || true
"${BASE_DIR}/slave1/stop.sh" || true
"${BASE_DIR}/slave2/stop.sh" || true
