#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "${SCRIPT_DIR}"

./redis-server ./redis.conf
echo "[INSTANCE] Started Redis with $(pwd)/redis.conf"
