#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "${SCRIPT_DIR}"

PIDFILE="data/redis_8102.pid"

if [[ -f "${PIDFILE}" ]]; then
  PID="$(cat "${PIDFILE}")"
  if kill -0 "${PID}" >/dev/null 2>&1; then
    echo "[INSTANCE] Stopping Redis (PID=${PID})..."
    kill "${PID}"
  else
    echo "[INSTANCE] PID ${PID} not running, removing stale pidfile."
  fi
  rm -f "${PIDFILE}"
else
  echo "[INSTANCE] PID file ${PIDFILE} not found."
fi
