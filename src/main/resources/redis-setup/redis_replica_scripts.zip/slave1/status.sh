#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "${SCRIPT_DIR}"

PIDFILE="data/redis_8101.pid"

if [[ -f "${PIDFILE}" ]]; then
  PID="$(cat "${PIDFILE}")"
  if kill -0 "${PID}" >/dev/null 2>&1; then
    echo "[INSTANCE] RUNNING (PID=${PID}, PIDFILE=${PIDFILE})"
  else
    echo "[INSTANCE] NOT RUNNING (stale PID=${PID}, PIDFILE=${PIDFILE})"
  fi
else
  echo "[INSTANCE] NOT RUNNING (no PIDFILE=${PIDFILE})"
fi
