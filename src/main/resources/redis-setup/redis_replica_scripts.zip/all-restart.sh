#!/usr/bin/env bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

"${BASE_DIR}/all-stop.sh" || true
sleep 1
"${BASE_DIR}/all-start.sh"
