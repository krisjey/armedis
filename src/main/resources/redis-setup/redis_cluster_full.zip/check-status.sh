#!/usr/bin/env bash
set -euo pipefail
IP="192.168.56.105"
for p in $(seq 17001 17006); do
  echo "=== ${IP}:${p} ==="
  redis-cli -h "$IP" -p "$p" cluster info | grep cluster_state
  redis-cli -h "$IP" -p "$p" cluster nodes | awk '{print substr($1,1,8),$3,$2}'
done
