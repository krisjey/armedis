#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
for node in node1 node2 node3 node4 node5 node6; do
  "${BASE_DIR}/${node}/start.sh"
done
