#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
REDIS_BIN_SRC="${REDIS_BIN_SRC:-/work/install/redis-7.4.4/src/redis-server}"
REDIS_CONF_SRC="${REDIS_CONF_SRC:-/work/install/redis-7.4.4/redis.conf}"
IP="192.168.56.105"
START_PORT=17001
NODE_COUNT=6
if [[ ! -x "$REDIS_BIN_SRC" ]]; then echo "redis-server not found"; exit 1; fi
if [[ ! -f "$REDIS_CONF_SRC" ]]; then echo "redis.conf not found"; exit 1; fi
for i in $(seq 0 $((NODE_COUNT-1))); do
  port=$((START_PORT+i)); idx=$((i+1)); node_dir="${BASE_DIR}/node${idx}"
  mkdir -p "$node_dir"
  cp "$REDIS_BIN_SRC" "${node_dir}/redis-server"
  cp "$REDIS_CONF_SRC" "${node_dir}/redis.conf"
  chmod +x "${node_dir}/redis-server"
  sed -i -e 's/^bind .*/# bind overridden/' -e 's/^protected-mode .*/# protected-mode overridden/' "${node_dir}/redis.conf"
  cat > "${node_dir}/redis-${port}.conf" <<EOF
include ${node_dir}/redis.conf
port ${port}
bind ${IP}
protected-mode no
daemonize yes
pidfile ${node_dir}/redis-${port}.pid
logfile ${node_dir}/redis-${port}.log
dir ${node_dir}
cluster-enabled yes
cluster-config-file nodes-${port}.conf
cluster-node-timeout 5000
cluster-announce-ip ${IP}
cluster-announce-port ${port}
cluster-announce-bus-port $((port+10000))
appendonly yes
EOF
  cat > "${node_dir}/start.sh" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
CONF_FILE="$(ls "$BASE_DIR"/redis-*.conf | head -n1)"
"$BASE_DIR/redis-server" "$CONF_FILE"
EOS
  cat > "${node_dir}/stop.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="\$(cd "\$(dirname "\$0")" && pwd)"
PIDFILE="\$(ls "\$BASE_DIR"/redis-*.pid 2>/dev/null | head -n1)"
if [[ -f "\$PIDFILE" ]]; then kill \$(cat "\$PIDFILE") || true; fi
EOF
  chmod +x "${node_dir}/start.sh" "${node_dir}/stop.sh"
done
