#!/usr/bin/env bash
set -euo pipefail
IP="192.168.56.105"
redis-cli --cluster create \
  ${IP}:17001 ${IP}:17002 ${IP}:17003 \
  ${IP}:17004 ${IP}:17005 ${IP}:17006 \
  --cluster-replicas 1
