#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
IP="192.168.56.105"
TARGET="${1:-17001}"
OBS="${2:-17002}"
idx=$((TARGET-17001+1))
node_dir="${BASE_DIR}/node${idx}"
pidfile="${node_dir}/redis-${TARGET}.pid"
kill $(cat "$pidfile") || true
for i in $(seq 1 10); do
  redis-cli -h "$IP" -p "$OBS" cluster nodes | grep master
  sleep 2
done
